<?php $__env->startSection('custom-css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <div class="page-content">

        <nav class="page-breadcrumb">
            <ol class="breadcrumb">

            </ol>
        </nav>

        <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Patient Details</h4>
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="mb-3">
                                    <strong>First Name:</strong> <?php echo e($patient->first_name); ?>

                                </div>
                            </div><!-- Col -->
                            <div class="col-sm-4">
                                <div class="mb-3">
                                    <strong>Last Name:</strong> <?php echo e($patient->last_name); ?>

                                </div>
                            </div><!-- Col -->
                            <div class="col-sm-4">
                                <div class="mb-3">
                                    <strong>Date of Birth:</strong> <?php echo e($patient->date_of_birth); ?>

                                </div>
                            </div><!-- Col -->
                        </div><!-- Row -->

                        <div class="row">
                            <div class="col-sm-4">
                                <div class="mb-3">
                                    <strong>Gender:</strong> <?php echo e($patient->gender); ?>

                                </div>
                            </div><!-- Col -->
                            <div class="col-sm-4">
                                <div class="mb-3">
                                    <strong>Email:</strong> <?php echo e($patient->email); ?>

                                </div>
                            </div><!-- Col -->
                            <div class="col-sm-4">
                                <div class="mb-3">
                                    <strong>Phone:</strong> <?php echo e($patient->phone); ?>

                                </div>
                            </div><!-- Col -->
                        </div><!-- Row -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="mb-3">
                                    <strong>Address:</strong> <?php echo e($patient->address); ?>

                                </div>
                            </div><!-- Col -->
                        </div><!-- Row -->
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="mb-3">
                                    <strong>City:</strong> <?php echo e($patient->city); ?>

                                </div>
                            </div><!-- Col -->
                            <div class="col-sm-4">
                                <div class="mb-3">
                                    <strong>State:</strong> <?php echo e($patient->state); ?>

                                </div>
                            </div><!-- Col -->
                            <div class="col-sm-4">
                                <div class="mb-3">
                                    <strong>Zip Code:</strong> <?php echo e($patient->zip_code); ?>

                                </div>
                            </div><!-- Col -->
                        </div><!-- Row -->



                        <a href="<?php echo e(route('patients.edit', $patient)); ?>" class="btn btn-inverse-warning">Edit</a>
                        <form action="<?php echo e(route('patients.destroy', $patient)); ?>" method="POST" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-inverse-danger" onclick="return confirm('Are you sure you want to delete this patient?')">Delete</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('libraries'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\patient-mgmt-breeze\resources\views/patients/show.blade.php ENDPATH**/ ?>