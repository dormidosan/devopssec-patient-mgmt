<?php $__env->startSection('custom-css'); ?>
    <!-- Plugin css for this page -->
    <link rel="stylesheet" href="<?php echo e(asset('../../../assets/vendors/datatables.net-bs5/dataTables.bootstrap5.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <div class="page-content">

        <nav class="page-breadcrumb">
            <a href="<?php echo e(route('diseases.create')); ?>" class="btn btn-inverse-success">Insert patient </a>

        </nav>

        <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h6 class="card-title">Patient Records</h6>
                        <div class="table-responsive">
                            <table id="dataTableExample" class="table">
                                <thead>
                                <tr>
                                    <th>Disease Name</th>
                                    <th>Approx duration</th>
                                    <th>Virus/Parasite</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $diseases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $disease): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($disease->name); ?></td>
                                        <td><?php echo e($disease->duration); ?></td>
                                        <td><?php echo e($disease->vector); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('diseases.show', $disease)); ?>" class="btn btn-inverse-primary">Show</a>
                                            <a href="<?php echo e(route('diseases.edit', $disease)); ?>" class="btn btn-inverse-warning">Edit</a>
                                            <form action="<?php echo e(route('diseases.destroy', $disease)); ?>" method="POST" style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-inverse-danger" onclick="return confirm('Are you sure you want to delete this disease?')">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('libraries'); ?>
    <script src="<?php echo e(asset('../assets/vendors/datatables.net/jquery.dataTables.js')); ?>" ></script>
    <script src="<?php echo e(asset('../../../assets/vendors/datatables.net-bs5/dataTables.bootstrap5.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(function() {
            'use strict';

            const dataTableExample = $('#dataTableExample');

            $(function() {
                dataTableExample.DataTable({
                    "aLengthMenu": [
                        [10, 30, 50, -1],
                        [10, 30, 50, "All"]
                    ],
                    "iDisplayLength": 10,
                    "language": {
                        search: ""
                    }
                });
                dataTableExample.each(function() {
                    const datatable = $(this);
                    // SEARCH - Add the placeholder for Search and Turn this into in-line form control
                    const search_input = datatable.closest('.dataTables_wrapper').find('div[id$=_filter] input');
                    search_input.attr('placeholder', 'Search');
                    search_input.removeClass('form-control-sm');
                    // LENGTH - Inline-Form control
                    const length_sel = datatable.closest('.dataTables_wrapper').find('div[id$=_length] select');
                    length_sel.removeClass('form-control-sm');
                });
            });


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\patient-mgmt-breeze\resources\views/diseases/index.blade.php ENDPATH**/ ?>